import java.util.Scanner;

class HelloWorld {
    public static void main(String[] args) {

        String nome = "";
        int idade = 0;
        double peso = 0.0;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe seus dados:  ");

        // Solicitar e ler idade
        System.out.print("Idade: ");
        idade = scanner.nextInt();

        // Solicitar e ler peso
        System.out.print("Peso: ");
        peso = scanner.nextDouble();

        // Consumir a quebra de linha pendente
        scanner.nextLine();

        // Solicitar e ler nome
        System.out.print("Nome: ");
        nome = scanner.nextLine();

        scanner.close();

        System.out.println("Informações fornecidas:");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Peso: " + peso);
    }
}
